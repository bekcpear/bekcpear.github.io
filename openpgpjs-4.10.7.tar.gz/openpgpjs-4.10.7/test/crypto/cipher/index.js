describe('Cipher', function () {
  require('./aes.js');
  require('./blowfish.js');
  require('./cast5.js');
  require('./des.js');
  require('./twofish.js');
});
