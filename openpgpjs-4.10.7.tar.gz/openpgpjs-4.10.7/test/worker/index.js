describe('Web Worker', function () {
  require('./async_proxy.js');
  require('./application_worker.js');
});

