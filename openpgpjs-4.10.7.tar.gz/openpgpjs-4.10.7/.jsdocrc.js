module.exports = {
    plugins: ['plugins/markdown']
};
